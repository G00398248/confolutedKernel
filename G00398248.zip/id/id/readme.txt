


**** Filtering an Image with a Convolution Kernel - G00398248/Paul Byrne ****




FILTER CLASS

getWidth/height and type of image gets how many pixels high and wide the image is and 
makes sure the new image has these values.

i & j used instead of row and column.

Try catch sets the pixel of our new image to the new pixel.

New pixel generated using array outputARGB

A for alpha is the transparency channel, 255 fully visible.

x & y coordinates we take in and y & j are the offset of the filter.

We seperate and store ARGB components in the array - int[] elementARGB.

Bit manipulation gets out the values we need. 




IMAGE SELECT UI

selectDirectory creates a new scanner
changes colour
scans for nextline
checks directory
checks if valid
if it is - directory = new directory
returns directory

New directory acts as a quarantine before accepting directory.

