package ie.gmit.dip;

public class StartUI {
	
	public static void displayStartMenu() {
		System.out.println(ConsoleColour.BLUE_BRIGHT);
		System.out.println("***************************************************");
		System.out.println("* GMIT - Dept. Computer Science & Applied Physics *");
		System.out.println("*                                                 *");
		System.out.println("*           Image Filtering System V0.1           *");
		System.out.println("*     H.Dip in Science (Software Development)     *");
		System.out.println("*                                                 *");
		System.out.println("***************************************************");

		System.out.println(ConsoleColour.WHITE);
		System.out.println("1) Enter Image Name"); // Ask user to specify the file to process. Do NOT hardcode paths
													// or file names
		System.out.println("2) Select A Filter"); // List the set of filters available in the class Kernel.java
		System.out.println("3) Change Output Image Name"); // Add as many options to the menu as you like and
																	// feel free to restructure it in any way.
		System.out.println("4) Quit and Render"); // Terminate
		System.out.println(ConsoleColour.YELLOW_BOLD);
		System.out.println("\nSelect Option [1-4]>");

		System.out.print(ConsoleColour.BLACK_BOLD_BRIGHT);
		System.out.println(ConsoleColour.RESET);
	}
}
