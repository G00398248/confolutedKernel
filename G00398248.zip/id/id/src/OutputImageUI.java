package ie.gmit.dip;

import java.util.Scanner;

public class OutputImageUI {
	
	public static String displayOutputImageUI(Scanner scanner, String outputImage) {
		System.out.println(ConsoleColour.BLUE_BRIGHT);
		System.out.println("***************************************************");
		System.out.println("*                Name Output Image                *");
		System.out.println("*                                                 *");
		System.out.println("***************************************************");
		System.out.println(ConsoleColour.WHITE);
		System.out.print("\nCurrent file: " + outputImage + ".png\n");
		scanner = new Scanner(System.in);
		System.out.println(ConsoleColour.YELLOW_BOLD);
		System.out.print("\nPlease enter the name of output file: \n");
		System.out.println(ConsoleColour.GREEN);
		if (scanner.hasNextLine())
			outputImage = scanner.nextLine();
		outputImage += ".png";
		//outputImage =(new StringBuilder()).append(".png").toString();  
		return outputImage;
	}
}
