package ie.gmit.dip;

import java.awt.image.BufferedImage;
import java.util.Scanner;

public class Runner {

	public static void main(String[] args) throws Exception {

		// Modifiable variables
		String imageName = "gmit-rgb.png";
		String directory = "C:\\Users\\PaulsPc\\Desktop\\images";
		String outputImage = "output";

		Scanner scanner = new Scanner(System.in);
		System.out.println(ConsoleColour.GREEN);
		double[][] filter = Kernel.IDENTITY;

		int userInput = 0;

		boolean programRunning = true;
		while (programRunning) {
			userInput = switch (userInput) {
			case 1:
				String[] directoryAndImageName = ImageSelectUI.displayImageSelectUI(scanner, directory, imageName);
				directory = directoryAndImageName[0];
				imageName = directoryAndImageName[1];
				yield 0;
			case 2:
				FilterSelectUI.displayFilterSelectScreen();
				filter = FilterSelectUI.selectFilter(scanner);
				yield 0;
			case 3:
				outputImage = OutputImageUI.displayOutputImageUI(scanner, outputImage);
				yield 0;
			case 4:
				BufferedImage image = ImageHandler.createBufferedImage(directory, imageName); // i.e gmit-rgb.png
				BufferedImage newImage = Filter.processImage(image, filter);
				ImageHandler.writePNG(newImage, directory, outputImage + ".png");
				scanner.close();
				System.out.println(ConsoleColour.PURPLE);
				System.out.println("\nRender Successful!\n");
				System.out.println("\nApplication Quit\n");
				programRunning = false;
				yield 0;
			default:
				StartUI.displayStartMenu();
				userInput = getUserInput(scanner);
				yield userInput;
			};
		}
		System.out.println(ConsoleColour.RESET);
	}

	private static int getUserInput(Scanner scanner) {
		scanner = new Scanner(System.in);
		int result = 0;
		while (result == 0) {
			System.out.println(ConsoleColour.GREEN);
			if (scanner.hasNextLine()) {
				result = switch (scanner.nextLine()) {
				case "1":
					yield 1;
				case "2":
					yield 2;
				case "3":
					yield 3;
				case "4":
					yield 4;
				default:
					System.out.println(ConsoleColour.RED_BOLD);
					System.out.println("\nInvalid input please enter a number between 1-4\n");
					System.out.println(ConsoleColour.GREEN);
					yield 0;
				};
			}
		}
		System.out.println(ConsoleColour.RESET);
		return result;
	}
}