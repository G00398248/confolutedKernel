package ie.gmit.dip;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * Class responsible for creating and managing images
 */
public class ImageHandler {
	
	public static BufferedImage createBufferedImage(String directory, String fileName) {
		BufferedImage image = null;
		String imageLocation = directory + "\\" + fileName;
		try {
			image = ImageIO.read(new File(imageLocation)); // i.e fileName = "picture.png"
		} catch (IOException e) {
			e.printStackTrace();
		}
		DeveloperControls.printImage(image);
		return image;
	}
	
	public static void writePNG(BufferedImage image, String directory, String fileName) {
		String writeLocation = directory + "\\" + fileName;
		try {
			ImageIO.write(image, "png", new File(writeLocation)); // i.e fileName = "out.png"
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(ConsoleColour.PURPLE);
		DeveloperControls.print("Image Write Complete!");
	}
}
