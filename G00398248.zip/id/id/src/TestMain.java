package ie.gmit.dip;

import java.awt.image.BufferedImage;

public class TestMain {

	public static void main(String[] args) throws Exception {
		
		// Load in an image
//		BufferedImage image1 = ImageHandler.createBufferedImage("gmit-rgb.png");
//		BufferedImage image2 = ImageHandler.createBufferedImage("gmit-gs.png");
//		BufferedImage image3 = ImageHandler.createBufferedImage("bridge-rgb.png");
//		BufferedImage image4 = ImageHandler.createBufferedImage("bridge-gs.png");
//		
//		// Filter the image
//		BufferedImage newImage1 = Filter.processImage(image1, Kernel.BOX_BLUR);
//		BufferedImage newImage2 = Filter.processImage(image2, Kernel.DIAGONAL_45_LINES);
//		BufferedImage newImage3 = Filter.processImage(image3, Kernel.HORIZONTAL_LINES);
//		BufferedImage newImage4 = Filter.processImage(image4, Kernel.VERTICAL_LINES);
//		
//		// Write the image to a file
//		ImageHandler.writePNG(newImage1, "testImage1.png");
//		ImageHandler.writePNG(newImage2, "testImage2.png");
//		ImageHandler.writePNG(newImage3, "testImage3.png");
//		ImageHandler.writePNG(newImage4, "testImage4.png");
	}
}
