package ie.gmit.dip;

import java.util.Scanner;

public class FilterSelectUI {

	public static void displayFilterSelectScreen() {
		System.out.println(ConsoleColour.BLUE_BRIGHT);
		System.out.println("***************************************************");
		System.out.println("*                Filter Selection                 *");
		System.out.println("*                                                 *");
		System.out.println("***************************************************");
		System.out.println(ConsoleColour.WHITE);
		System.out.println("Select a filter listed below:");
		System.out.println("1) Identity");
		System.out.println("2) Edge Detection 1");
		System.out.println("3) Edge Detection 2");
		System.out.println("4) Laplacian");
		System.out.println("5) Sharpen");
		System.out.println("6) Vertical Lines");
		System.out.println("7) Horizontal Lines");
		System.out.println("8) Diagonal 45 Lines");
		System.out.println("9) Box Blur");
		System.out.println("10) Sobel Horizontal");
		System.out.println("11) Sobel Vertical");
		System.out.println(ConsoleColour.RESET);
	}

	public static double[][] selectFilter(Scanner scanner) {
		System.out.println(ConsoleColour.YELLOW_BOLD);
		System.out.println("\nSelect Option [1-11]>");
		double[][] filter = Kernel.IDENTITY;
		boolean inputIsValid = false;
		while (inputIsValid == false) {
			scanner = new Scanner(System.in);
			System.out.println(ConsoleColour.GREEN);
			int filterNumber = 0;
			if (scanner.hasNextInt())
				filterNumber = scanner.nextInt();
			switch (filterNumber) {
			case 1:
				filter = Kernel.IDENTITY;
				inputIsValid = true;
				break;
			case 2:
				filter = Kernel.EDGE_DETECTION_1;
				inputIsValid = true;
				break;
			case 3:
				filter = Kernel.EDGE_DETECTION_2;
				inputIsValid = true;
				break;
			case 4:
				filter = Kernel.LAPLACIAN;
				inputIsValid = true;
				break;
			case 5:
				filter = Kernel.SHARPEN;
				inputIsValid = true;
				break;
			case 6:
				filter = Kernel.VERTICAL_LINES;
				inputIsValid = true;
				break;
			case 7:
				filter = Kernel.HORIZONTAL_LINES;
				inputIsValid = true;
				break;
			case 8:
				filter = Kernel.DIAGONAL_45_LINES;
				inputIsValid = true;
				break;
			case 9:
				filter = Kernel.BOX_BLUR;
				inputIsValid = true;
				break;
			case 10:
				filter = Kernel.SOBEL_HORIZONTAL;
				inputIsValid = true;
				break;
			case 11:
				filter = Kernel.SOBEL_VERTICAL;
				inputIsValid = true;
				break;
			default:
				System.out.println(ConsoleColour.RED);
				System.out.println("\nPlease enter a number between 1-11");
			}
		}
		System.out.println(ConsoleColour.RESET);
		return filter;
	}
}
