package ie.gmit.dip;

import java.awt.image.BufferedImage;

/*
 * Class responsible for applying different filters (kernels) to the images
 */
public class Filter {

	//static double[][] filter = Kernel.IDENTITY;	// Change IDENTITY to be whatever filter you want. Identity is standard and will not change the image

	public static BufferedImage processImage(BufferedImage image, double[][] filter) {
		BufferedImage newImage = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
		for (int i = 0; i < image.getWidth(); i++) {
			for (int j = 0; j < image.getHeight(); j++) {
				int newPixel = apply(image, i, j, filter);
				try {
					newImage.setRGB(i + 1, j + 1, newPixel);
				} catch (Exception e) {
					continue;
				}
			}
		}
		return newImage;
	}

	public static int apply(BufferedImage image, int x, int y, double[][] filter) {
		int[] outputARGB = new int[4];
		for (int i = 0; i < filter.length; i++) {
			for (int j = 0; j < filter[i].length; j++) {
				try {
					int element = image.getRGB(x + i, y + j);
					int[] elementARGB = new int[4];

					elementARGB[0] = (element >> 24) & 0xff;
					elementARGB[1] = (element >> 16) & 0xff;
					elementARGB[2] = (element >> 8) & 0xff;
					elementARGB[3] = element & 0xff;

					if (i == 1 && j == 1) {
						elementARGB[0] = (int) (elementARGB[0] * filter[i][j]);
						outputARGB[0] = elementARGB[0];
					}

					for (int index = 1; index < outputARGB.length; index++) {
						elementARGB[index] = (int) (elementARGB[index] * filter[i][j]);
						outputARGB[index] += elementARGB[index];
					}

				} catch (Exception e) {
					continue;
				}
			}
		}
		int output = generateOutput(outputARGB);
		return output;
	}

	private static int generateOutput(int[] outputARGB) {
		outputARGB[0] = fixOutOfRangeValue(outputARGB[0]);
		outputARGB[1] = fixOutOfRangeValue(outputARGB[1]);
		outputARGB[2] = fixOutOfRangeValue(outputARGB[2]);
		outputARGB[3] = fixOutOfRangeValue(outputARGB[3]);

		int output = 0;
		output = output | (outputARGB[0] << 24);
		output = output | (outputARGB[1] << 16);
		output = output | (outputARGB[2] << 8);
		output = output | outputARGB[3];
		return output;
	}

	private static int fixOutOfRangeValue(int value) {
		if (value < 0)
			value = -value;
		if (value > 255)
			return 255;
		else
			return value;
	}
}