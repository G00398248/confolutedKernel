package ie.gmit.dip;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class ImageSelectUI {

	public static String[] displayImageSelectUI(Scanner scanner, String directory, String imageName) {
		displayUI(directory, imageName);
		String[] directoryAndImageName = getUserInput(scanner, directory, imageName);
		return directoryAndImageName;
	}

	public static void displayUI(String directory, String imageName) {
		System.out.println(ConsoleColour.BLUE_BRIGHT);
		System.out.println("***************************************************");
		System.out.println("*                 Image Selection                 *");
		System.out.println("*                                                 *");
		System.out.println("***************************************************");
		System.out.println(ConsoleColour.WHITE);
		System.out.print("\nCurrent directory: " + directory + "\n");
		System.out.print("\nCurrent file: " + imageName + "\n");
		System.out.println("\nSelect an option listed below:");
		System.out.println("1) Change directory");
		System.out.println("2) Change file name");
		System.out.println(ConsoleColour.YELLOW_BOLD);
		System.out.println("\nSelect Option [1-2] or any other key to return>");
	}

	public static String[] getUserInput(Scanner scanner, String directory, String imageName) {
		System.out.println(ConsoleColour.GREEN);
		scanner = new Scanner(System.in);
		int input = 0;
		if (scanner.hasNextInt())
			input = scanner.nextInt();
		switch (input) {
		case 1:
			directory = selectDirectory(scanner, directory, imageName);
			break;
		case 2:
			imageName = selectImageName(scanner, directory, imageName);
			break;
		}
		String[] directoryAndImageName = { directory, imageName };
		return directoryAndImageName;
	}

	public static String selectImageName(Scanner scanner, String directory, String image) {
		String newImage = "";
		System.out.println(ConsoleColour.YELLOW_BOLD);
		System.out.print("\nPlease enter the file name: \n");
		boolean inputIsValid = false;
		while (inputIsValid == false) {
			scanner = new Scanner(System.in);
			System.out.println(ConsoleColour.GREEN);
			if (scanner.hasNextLine()) {
				newImage = scanner.nextLine();
				try {
					String imageLocation = directory + "\\" + newImage;
					BufferedImage testImage = ImageIO.read(new File(imageLocation));
					image = newImage;
					inputIsValid = true;
				} catch (Exception e) {
					System.out.println(ConsoleColour.RED);
					System.out.print("\nInvalid file name, please enter another file name\n");
				}
			}
		}
		System.out.println(ConsoleColour.GREEN);
		System.out.print("\nFile located!\n");
		return image;
	}

	public static String selectDirectory(Scanner scanner, String directory, String imageName) {
		String newDirectory = "";
		System.out.println(ConsoleColour.YELLOW_BOLD);
		System.out.print("\nPlease enter the directory: \n");
		boolean inputIsValid = false;
		while (inputIsValid == false) {
			scanner = new Scanner(System.in);
			System.out.println(ConsoleColour.GREEN);
			if (scanner.hasNextLine()) {
				newDirectory = scanner.nextLine();
				try {
					String imageLocation = newDirectory + "\\" + imageName;
					BufferedImage testImage = ImageIO.read(new File(imageLocation));
					directory = newDirectory;
					inputIsValid = true;
				} catch (Exception e) {
					System.out.println(ConsoleColour.RED);
					System.out.print("\nInvalid directory, please enter another directory\n");
				}
			}
		}
		return directory;
	}
}
