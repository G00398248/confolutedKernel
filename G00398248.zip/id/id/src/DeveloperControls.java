package ie.gmit.dip;

import java.awt.image.BufferedImage;

public class DeveloperControls {
	
	private static final boolean ENABLE_DEVELOPER_PRINT_STATEMENTS = false; // When true extra data will be printed

	public static void printImage(BufferedImage image) {
		if (ENABLE_DEVELOPER_PRINT_STATEMENTS)
			System.out.println(image); // This writes out a lot of useful meta-data about the image.
	}

	public static void print(String text) {
		if (ENABLE_DEVELOPER_PRINT_STATEMENTS)
			System.out.println(text);
	}
}
